# Demo Project

This is a demo project loaded from a ZIP file into VS Code Web.

## Getting Started

Edit any file — changes are kept in-memory (lost on page reload).
