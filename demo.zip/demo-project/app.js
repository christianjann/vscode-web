'use strict';

console.log('Hello from VS Code Web!');

document.addEventListener('DOMContentLoaded', () => {
	const p = document.querySelector('p');
	if (p) {
		p.textContent += ' Loaded at: ' + new Date().toLocaleTimeString();
	}
});
