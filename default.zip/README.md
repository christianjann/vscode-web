# VS Code Web — Static Build

This is [Visual Studio Code](https://code.visualstudio.com/) running entirely
in your browser as a static website.

- **Completely served by a static web server** (e.g. `python3 -m http.server 8080`)
- **Everything runs in the browser** — no backend, no Node.js runtime required
- It only needs a web server to serve the HTML and JavaScript as static files

## Author

Christian Jann <christian.jann@ymail.com>

## Source Code

https://github.com/christianjann/vscode-web

## Loading a Workspace

Via URL you can load a ZIP file into the workspace:

### Any ZIP served from the same server:
```
http://localhost:8080/?zip=./myproject.zip
```

### GitHub repo ZIP (public):
```
http://localhost:8080/?zip=https://codeload.github.com/USERNAME/REPO/zip/refs/heads/main
```

### Default workspace:
If a `default.zip` file exists in the served directory, it is loaded
automatically when visiting the page without any URL parameters.

To customize the default workspace, simply replace `default.zip` with
your own ZIP file.

## How It Works

The page redirects once (adding `&folder=tmp%3A%2F%2F%2Fworkspace`),
VS Code opens the empty in-memory folder, then the workspace-loader
extension fetches + unpacks the ZIP and populates it — you’ll see a
progress item in the status bar and a notification when done.

Files are editable but **in-memory only** (lost on reload).

## Open a Local Folder

In Chrome or Edge, you can also use **File > Open Folder** to open a
local directory directly from disk (using the File System Access API).
